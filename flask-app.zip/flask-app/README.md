
# Become a Tandarts — Full Project

## Structure
- `flask-app/` — основной сайт (Flask)
- `streamlit-app/` — интерактивные модули: тесты, язык, flashcards

## Как запустить
1. Установи зависимости:
```
pip install flask streamlit
```

2. Запуск Flask:
```
cd flask-app
python app.py
```

3. Запуск Streamlit:
```
cd streamlit-app
streamlit run app.py
```
