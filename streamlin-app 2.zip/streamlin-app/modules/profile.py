# modules/profile.py

import streamlit as st

def render():
    st.title("👤 Mijn Profiel")

    st.write("Welkom bij jouw persoonlijke dashboard!")
    st.info("Meer functies komen binnenkort, zoals registratie, CV-builder en documentchecklist voor BIG.")
